const userData = require('./userApi');

module.exports = {
  users: userData
};
