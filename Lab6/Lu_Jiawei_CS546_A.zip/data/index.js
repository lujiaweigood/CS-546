const postData = require('./bands');
const userData = require('./albums');

module.exports = {
  albums: userData,
  bands: postData
};
